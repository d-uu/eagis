import { motion } from 'motion/react';
import { companyData } from '../data';

export default function CompanyInfo() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6 } }
  };

  return (
    <section className="py-24 bg-zinc-950">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-20">
          <h2 className="text-3xl font-serif text-white tracking-wider mb-4">OPERATIONAL DOCTRINE</h2>
          <div className="h-px w-16 bg-zinc-700 mx-auto"></div>
        </div>

        <motion.div 
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-32"
        >
          {companyData.policies.map((policy, index) => (
            <motion.div 
              key={index} 
              variants={itemVariants}
              className="p-8 border border-zinc-800/50 bg-zinc-900/20 backdrop-blur-sm rounded-lg hover:bg-zinc-900/40 transition-colors"
            >
              <div className="text-zinc-400 mb-6">{policy.icon}</div>
              <h3 className="text-lg font-medium text-white mb-3">{policy.title}</h3>
              <p className="text-sm text-zinc-400 leading-relaxed font-light">{policy.desc}</p>
            </motion.div>
          ))}
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl font-serif text-white tracking-wider mb-8">INFRASTRUCTURE</h2>
            <div className="space-y-8">
              {companyData.infrastructure.map((item, index) => (
                <div key={index} className="flex gap-6">
                  <div className="flex-shrink-0 mt-1">
                    <div className="p-3 rounded-full bg-zinc-900 border border-zinc-800 text-zinc-400">
                      {item.icon}
                    </div>
                  </div>
                  <div>
                    <h4 className="text-white font-medium mb-1">{item.title}</h4>
                    <p className="text-zinc-400 text-sm font-light leading-relaxed">{item.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
          <motion.div
             initial={{ opacity: 0, x: 30 }}
             whileInView={{ opacity: 1, x: 0 }}
             transition={{ duration: 0.8 }}
             viewport={{ once: true }}
             className="relative h-[600px] w-full rounded-xl overflow-hidden border border-zinc-800 bg-zinc-900/50"
          >
            <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?q=80&w=2070&auto=format&fit=crop')] bg-cover bg-center opacity-20 mix-blend-luminosity"></div>
            <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-zinc-950/20 to-transparent"></div>
            <div className="absolute bottom-8 left-8 right-8">
              <p className="text-zinc-500 text-xs tracking-[0.2em] mb-2 uppercase">Headquarters</p>
              <p className="text-white font-serif text-2xl">Century City, Los Angeles</p>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
